﻿namespace GarageUI
{
    public class Program
    {
        static void Main()
        {
            GarageManagerUI ui = new GarageManagerUI();
            ui.runGarage();
        }
    }

}

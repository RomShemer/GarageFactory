﻿using System;
using GarageLogic.FuelEngineClass;
using GarageLogic.ElectricEngineClass;

namespace GarageLogic
{
    namespace EngineClass
    {
        public abstract class EngineType
        {
            public enum eEngineType
            {
                fuel = 1,
                electric
            }

            public static EngineType CreateEngineByType(EngineType.eEngineType i_engineType, float i_maxEnergyAmount, float i_currentEnergyAmount, FuelEngine.eFuelType i_fuelType = 0)
            {
                EngineType engine = null;

                switch (i_engineType)
                {
                    case EngineType.eEngineType.fuel:
                        engine = new FuelEngine(i_maxEnergyAmount, i_currentEnergyAmount, i_fuelType);
                        break;
                    case EngineType.eEngineType.electric:
                        engine = new ElectricEngine(i_maxEnergyAmount, i_currentEnergyAmount);
                        break;
                    default:
                        throw new ArgumentException("Invalid engine type");
                }

                return engine;
            }

            public abstract void GetCurrentEnergyDetails(out float o_currentAmountOfEnergy);

            public abstract void FillEnergy(float i_addEnergy);

            public abstract string ToString();
        }
    }
}